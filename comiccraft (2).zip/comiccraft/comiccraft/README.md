# ComicCraft

AI comic generator: FastAPI + Gemini (story) + Stable Diffusion (images) + PDF export.

## Setup
```bash
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env    # add your GEMINI_API_KEY
uvicorn main:app --reload
```
Open http://127.0.0.1:8000

## API
`POST /api/generate` with JSON: `prompt, character, setting, tone, art_style, panels`
`GET /api/pdf/{id}` downloads the PDF. Interactive docs at `/docs`.

## Notes
- First run downloads the Stable Diffusion model (~4 GB).
- A GPU is strongly recommended; CPU works but takes minutes per panel.
