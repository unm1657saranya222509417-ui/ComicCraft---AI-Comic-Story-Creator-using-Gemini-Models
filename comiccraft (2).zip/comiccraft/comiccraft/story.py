"""Story generation with Gemini."""
import json
import os
import re

import google.generativeai as genai

genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
model = genai.GenerativeModel("gemini-1.5-flash")


def generate_story(prompt, character, setting, tone, art_style, panels=4):
    """Return a list of panels: [{"scene": ..., "narration": ..., "dialogue": ...}]."""
    request = f"""
You are a comic book writer. Write a {panels}-panel comic.
Story idea: {prompt}
Main character: {character}
Setting: {setting}
Tone: {tone}
Art style: {art_style}

Reply ONLY with a JSON list of {panels} objects, each with keys:
"scene" (a visual description for an image generator, mention the character's look),
"narration" (one short sentence),
"dialogue" (one short line spoken by a character, or "" if none).
No markdown, no extra text.
"""
    text = model.generate_content(request).text
    text = re.sub(r"```json|```", "", text).strip()
    return json.loads(text)
