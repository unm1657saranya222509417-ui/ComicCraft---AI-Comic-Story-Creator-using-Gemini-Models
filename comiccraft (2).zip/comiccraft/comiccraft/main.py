"""ComicCraft - FastAPI app. Run: uvicorn main:app --reload"""
import uuid
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from images import generate_image
from pdf import build_pdf
from story import generate_story

OUT = Path("outputs")
OUT.mkdir(exist_ok=True)

app = FastAPI(title="ComicCraft")
app.mount("/outputs", StaticFiles(directory="outputs"), name="outputs")


class ComicRequest(BaseModel):
    prompt: str
    character: str = "Alex"
    setting: str = "a futuristic city"
    tone: str = "adventurous"
    art_style: str = "manga"
    panels: int = 4


@app.post("/api/generate")
def generate(req: ComicRequest):
    comic_id = uuid.uuid4().hex[:8]
    folder = OUT / comic_id
    folder.mkdir()
    try:
        panels = generate_story(req.prompt, req.character, req.setting,
                                req.tone, req.art_style, min(max(req.panels, 1), 8))
        for i, p in enumerate(panels, 1):
            path = folder / f"panel_{i}.png"
            generate_image(p["scene"], req.art_style, str(path))
            p["image_path"] = str(path)
            p["image_url"] = f"/outputs/{comic_id}/panel_{i}.png"
        build_pdf(f"{req.character}'s Story", panels, str(folder / "comic.pdf"))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    for p in panels:
        p.pop("image_path")
    return {"id": comic_id, "panels": panels, "pdf_url": f"/api/pdf/{comic_id}"}


@app.get("/api/pdf/{comic_id}")
def download_pdf(comic_id: str):
    path = OUT / comic_id / "comic.pdf"
    if not path.exists():
        raise HTTPException(status_code=404, detail="Comic not found")
    return FileResponse(path, media_type="application/pdf", filename="comic.pdf")


@app.get("/")
def home():
    return FileResponse("static/index.html")
