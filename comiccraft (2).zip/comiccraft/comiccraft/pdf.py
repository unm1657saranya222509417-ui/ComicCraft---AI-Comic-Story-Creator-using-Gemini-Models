"""Build the comic PDF."""
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas


def build_pdf(title, panels, pdf_path):
    width, height = A4
    c = canvas.Canvas(pdf_path, pagesize=A4)
    c.setFont("Helvetica-Bold", 24)
    c.drawCentredString(width / 2, height - 60, title)
    y = height - 100
    img_size = 300

    for i, p in enumerate(panels, 1):
        if y < img_size + 90:  # new page when out of space
            c.showPage()
            y = height - 50
        c.drawImage(ImageReader(p["image_path"]), (width - img_size) / 2,
                    y - img_size, img_size, img_size)
        c.setFont("Helvetica-Oblique", 11)
        c.drawCentredString(width / 2, y - img_size - 18, f"{i}. {p['narration']}")
        if p.get("dialogue"):
            c.setFont("Helvetica-Bold", 11)
            c.drawCentredString(width / 2, y - img_size - 36, f"\"{p['dialogue']}\"")
        y -= img_size + 70
    c.save()
    return pdf_path
