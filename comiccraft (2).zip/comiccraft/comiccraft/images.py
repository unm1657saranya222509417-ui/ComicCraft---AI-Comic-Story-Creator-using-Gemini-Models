"""Image generation with Stable Diffusion (Hugging Face Diffusers)."""
import os

import torch
from diffusers import StableDiffusionPipeline

_pipe = None


def _get_pipe():
    """Load the model once, on first use."""
    global _pipe
    if _pipe is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
        dtype = torch.float16 if device == "cuda" else torch.float32
        _pipe = StableDiffusionPipeline.from_pretrained(
            os.getenv("SD_MODEL", "runwayml/stable-diffusion-v1-5"),
            torch_dtype=dtype,
        ).to(device)
        _pipe.safety_checker = None
    return _pipe


def generate_image(scene, art_style, path, seed=42):
    """Generate one panel. A fixed seed helps keep the look consistent."""
    pipe = _get_pipe()
    generator = torch.Generator().manual_seed(seed)
    prompt = f"{scene}, {art_style} comic book illustration, vibrant colors, clean lines"
    image = pipe(
        prompt,
        negative_prompt="text, watermark, blurry, deformed, low quality",
        num_inference_steps=25,
        height=512,
        width=512,
        generator=generator,
    ).images[0]
    image.save(path)
    return path
